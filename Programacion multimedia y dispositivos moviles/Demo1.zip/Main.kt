package asir2.juego1

import asir2.juego1.screen.GameScreen
import asir2.juego1.screen.JuegoSuelo
import asir2.juego1.screen.JuegoSueloV2
import asir2.juego1.screen.JuegoSueloV3
import asir2.juego1.screen.JuegoSueloV4
import asir2.juego1.screen.JuegoSueloV5
import asir2.juego1.screen.JuegoSueloV6
import asir2.juego1.screen.MenuScreen
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.Texture.TextureFilter.Linear
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.utils.ScreenUtils
import ktx.app.KtxGame
import ktx.app.KtxScreen
import ktx.app.clearScreen
import ktx.assets.disposeSafely
import ktx.assets.toInternalFile
import ktx.async.KtxAsync
import ktx.graphics.use

class Main : KtxGame<KtxScreen>() {
    override fun create() {
        KtxAsync.initiate()
        // Añadimos ambas pantallas
        addScreen(MenuScreen(this))
        addScreen(JuegoSueloV3())
        addScreen(JuegoSueloV6(this))

        // Empezamos en el menú
        setScreen<MenuScreen>()
    }
}
//class Main : KtxGame<KtxScreen>() {
//    override fun create() {
//        KtxAsync.initiate()
//
//        addScreen(JuegoSueloV5())
//        setScreen<JuegoSueloV5>()
//    }
//}
