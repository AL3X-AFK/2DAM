package asir2.juego1.screen

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.graphics.g2d.TextureRegion
import com.badlogic.gdx.utils.ScreenUtils
import ktx.app.KtxScreen
import ktx.graphics.use

class JuegoSuelo : KtxScreen {
    private val batch = SpriteBatch()
    private val texturaCompleta = Texture("Terrain (16x16).png")
    private lateinit var tileHierba: TextureRegion
    private lateinit var tileHierba1: TextureRegion

    override fun show() {
        // Configuramos filtro para que no se vea borroso al escalar
        texturaCompleta.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest)

        // Suponiendo que cada bloque grande es de 48x48 píxeles
        // Ajusta el '48' si ves que corta el dibujo
        val tamañoTile = 16

        // Extraemos la región (x, y, ancho, alto)
        // La hierba verde está aproximadamente en x=48 (segundo bloque)
        tileHierba = TextureRegion(texturaCompleta, 128, 0, tamañoTile, tamañoTile)
        tileHierba1 = TextureRegion(texturaCompleta, 144, 0, tamañoTile, tamañoTile)
    }

    override fun render(delta: Float) {
        // Limpiamos la pantalla
        ScreenUtils.clear(0.1f, 0.1f, 0.1f, 1f)

        val tamañoTile = 16f

        batch.use { b ->
            // Bucle para cubrir el ancho de la pantalla
            for (x in 0 until (Gdx.graphics.width / tamañoTile.toInt() + 1)) {
                // Bucle para cubrir el alto (por ahora pintamos solo 3 filas de suelo)
                for (y in 0 until 1) {
                    b.draw(
                        tileHierba,
                        x * tamañoTile, // Posición X
                        y * tamañoTile, // Posición Y
                        tamañoTile,     // Ancho en pantalla
                        tamañoTile      // Alto en pantalla
                    )
                    b.draw(
                        tileHierba1,
                        x * tamañoTile, // Posición X
                        y * tamañoTile, // Posición Y
                        tamañoTile,     // Ancho en pantalla
                        tamañoTile      // Alto en pantalla
                    )
                    b.draw(
                        tileHierba1,
                        x * tamañoTile, // Posición X
                        y * tamañoTile, // Posición Y
                        tamañoTile,     // Ancho en pantalla
                        tamañoTile      // Alto en pantalla
                    )
                }
            }
        }
    }
}
