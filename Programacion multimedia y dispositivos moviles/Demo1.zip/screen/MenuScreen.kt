package asir2.juego1.screen

import asir2.juego1.Main
import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.g2d.BitmapFont
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.utils.ScreenUtils
import ktx.app.KtxScreen
import ktx.graphics.use

class MenuScreen(val game: Main) : KtxScreen {
    private val batch = SpriteBatch()
    private val font = BitmapFont()
    private val imagenPlay = Texture("Menu/Buttons/Play.png") // Puedes usar una imagen de botón si tienes

    override fun render(delta: Float) {
        ScreenUtils.clear(0.1f, 0.1f, 0.2f, 1f)

        batch.use { b ->
            font.data.setScale(3f)
            font.draw(b, "PINK RUNNER", 250f, 400f)

            b.draw(imagenPlay, 350f, 200f, 100f, 100f) // Dibujamos algo que actúe de botón

            font.data.setScale(1.5f)
            font.draw(b, "TOCA PARA JUGAR", 300f, 150f)
        }

        // Si el usuario toca la pantalla, cambiamos a la pantalla de juego
        if (Gdx.input.justTouched()) {
            game.setScreen<JuegoSueloV6>()
        }
    }
}
