package asir2.juego1.screen

import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.Texture.TextureFilter.Linear
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.utils.ScreenUtils
import ktx.app.KtxScreen
import ktx.assets.disposeSafely
import ktx.assets.toInternalFile
import ktx.graphics.use

class GameScreen : KtxScreen {
    private val image = Texture("Terrain (16x16).png".toInternalFile(), true).apply { setFilter(Linear, Linear) }
    private val batch = SpriteBatch()

    override fun render(delta: Float) {
        // Limpiamos pantalla (Color azulito)
        ScreenUtils.clear(0.1f, 0.1f, 0.2f, 1f)

        // Dibujamos el sprite
        batch.use { b ->
            b.draw(image, 100f, 100f)
        }
    }

    override fun dispose() {
        image.disposeSafely()
        batch.disposeSafely()
    }
}
