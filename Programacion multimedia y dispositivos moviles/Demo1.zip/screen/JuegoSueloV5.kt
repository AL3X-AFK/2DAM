package asir2.juego1.screen


import asir2.juego1.Jugador
import asir2.juego1.screen.GameScreen
import com.badlogic.gdx.Gdx
import com.badlogic.gdx.Input
import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.Texture.TextureFilter.Linear
import com.badlogic.gdx.graphics.g2d.Batch
import com.badlogic.gdx.graphics.g2d.BitmapFont
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.graphics.g2d.TextureRegion
import com.badlogic.gdx.math.Rectangle
import com.badlogic.gdx.utils.ScreenUtils
import com.badlogic.gdx.utils.viewport.FitViewport
import ktx.app.KtxGame
import ktx.app.KtxScreen
import ktx.app.clearScreen
import ktx.assets.disposeSafely
import ktx.assets.toInternalFile
import ktx.async.KtxAsync
import ktx.graphics.use

class JuegoSueloV5 : KtxScreen {

    // Para meter un bstaculo
    private lateinit var texObstaculo: Texture
    private var obstaculoX = 1200f // Posición inicial del primer obstáculo
    private var gameOver = false

    private val font = BitmapFont() // Fuente por defecto (Arial blanca)
    private var tiempoTranscurrido = 0f

    private lateinit var texIdle: Texture
    private lateinit var texRun: Texture
    private lateinit var texDoubleJump: Texture
    private lateinit var texJump: Texture
    private lateinit var texFall: Texture
    private lateinit var texBlock: Texture
    private lateinit var jugador: Jugador

    private val batch = SpriteBatch()
    private val camera = OrthographicCamera()
    private val texturaMapa = Texture("map.png") // Usamos tu imagen de mapa completa

    // Posición virtual de nuestra cámara
    private var camX = 400f

    override fun show() {
        // Cargamos los archivos que subiste
        texIdle = Texture("Pink Man/Idle (32x32).png")
        texRun = Texture("Pink Man/Run (32x32).png")
        texDoubleJump = Texture("Pink Man/Double Jump (32x32).png")
        texJump = Texture("Pink Man/Jump (32x32).png")
        texFall = Texture("Pink Man/Fall (32x32).png")
        texBlock = Texture("Rock Head/Idle.png")

        // Instanciamos al jugador pasándole estas texturas
        jugador = Jugador(texIdle, texRun, texJump, texDoubleJump, texFall)

        camera.setToOrtho(false, 800f, 480f)
    }

    override fun render(delta: Float) {
        if (gameOver) {
            // Si perdemos, podemos reiniciar pulsando el ratón
            if (Gdx.input.justTouched()) reiniciarJuego()
            return
        }
        // 1. LÓGICA DE TIEMPO Y DIFICULTAD
        tiempoTranscurrido += delta

        // Velocidad base + (segundos * incremento)
        val velocidadActual = 200f + (tiempoTranscurrido * 5f)

        // 2. INPUT (Salto por clic)
        if (Gdx.input.justTouched() && !jugador.estaEnAire) {
            jugador.velocidadY = 650f // Un poco más de fuerza para compensar la velocidad
        }

        // 3. ACTUALIZACIÓN DEL MUNDO
        jugador.update(delta, velocidadActual)

        // La cámara sigue al jugador (lo posicionamos a la izquierda para ver qué viene)
//        camera.position.set(jugador.posicionX + 250f, 240f, 0f)
//        camera.update()

        // El obstáculo se queda quieto en el mundo, pero como el jugador avanza
        // y la cámara le sigue, parece que el obstáculo viene hacia nosotros.
        // Si el obstáculo sale de la pantalla por la izquierda, lo reposicionamos delante
        if (camera.position.x - obstaculoX > 500f) {
            obstaculoX = jugador.posicionX + 800f + (Math.random() * 400).toFloat()
        }

        // 3. SISTEMA DE COLISIONES
        val hitboxJugador = jugador.getHitbox()
        val hitboxObstaculo = Rectangle(obstaculoX, 36f, 32f, 32f)

        if (hitboxJugador.overlaps(hitboxObstaculo)) {
            gameOver = true
        }

        camera.position.set(jugador.posicionX + 250f, 240f, 0f)
        camera.update()

        // 4. DIBUJADO
        ScreenUtils.clear(0f, 0f, 0f, 1f)
        batch.projectionMatrix = camera.combined

        batch.use { b ->
            val anchoMapa = texturaMapa.width.toFloat()
            val offsetMapa = (jugador.posicionX / anchoMapa).toInt()

            // Dibujamos el mapa infinito
            for (i in -1..3) {
                b.draw(texturaMapa, (offsetMapa + i) * anchoMapa, 0f)
            }

            // Dibujamos el obstáculo
            b.draw(texBlock, obstaculoX, 36f, 32f, 32f)

            // Dibujamos al personaje (siempre corriendo)
            val frameActual = jugador.getFrame(true, false)
            b.draw(frameActual, jugador.posicionX, jugador.posicionY, 32f, 32f)

            // --- INTERFAZ (UI) ---
            // Usamos una matriz fija para que el marcador no se mueva
            val matrizUI = camera.combined.cpy().setToOrtho2D(0f, 0f, 800f, 480f)
            b.projectionMatrix = matrizUI
            font.data.setScale(1.5f)

            // Datos en pantalla
            val seg = tiempoTranscurrido.toInt()
            val metros = (jugador.posicionX / 50).toInt() // Distancia relativa


            b.projectionMatrix = camera.combined.cpy().setToOrtho2D(0f, 0f, 800f, 480f)
            if (gameOver) {
                font.draw(b, "¡GAME OVER! Toca para reiniciar", 250f, 240f)
            } else {

                font.draw(b, "TIEMPO: ${seg}s", 20f, 460f)
                font.draw(b, "DISTANCIA: ${metros}m", 20f, 430f)
                font.draw(b, "VELOCIDAD: ${velocidadActual.toInt()}", 600f, 460f)
            }
        }
    }

    private fun reiniciarJuego() {
        tiempoTranscurrido = 0f
        jugador.posicionX = 400f
        obstaculoX = 1200f
        gameOver = false
    }

    override fun dispose() {
        batch.disposeSafely()
        font.dispose() // ¡Importante!
    }
}
