package asir2.juego1.screen


import asir2.juego1.Jugador
import asir2.juego1.screen.GameScreen
import com.badlogic.gdx.Gdx
import com.badlogic.gdx.Input
import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.Texture.TextureFilter.Linear
import com.badlogic.gdx.graphics.g2d.Batch
import com.badlogic.gdx.graphics.g2d.BitmapFont
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.graphics.g2d.TextureRegion
import com.badlogic.gdx.utils.ScreenUtils
import com.badlogic.gdx.utils.viewport.FitViewport
import ktx.app.KtxGame
import ktx.app.KtxScreen
import ktx.app.clearScreen
import ktx.assets.disposeSafely
import ktx.assets.toInternalFile
import ktx.async.KtxAsync
import ktx.graphics.use

class JuegoSueloV4 : KtxScreen {

    private val font = BitmapFont() // Fuente por defecto (Arial blanca)
    private var tiempoTranscurrido = 0f

    private lateinit var texIdle: Texture
    private lateinit var texRun: Texture
    private lateinit var texDoubleJump: Texture
    private lateinit var texJump: Texture
    private lateinit var texFall: Texture
    private lateinit var jugador: Jugador

    private val batch = SpriteBatch()
    private val camera = OrthographicCamera()
    private val texturaMapa = Texture("map.png") // Usamos tu imagen de mapa completa

    // Posición virtual de nuestra cámara
    private var camX = 400f

    override fun show() {
        // Cargamos los archivos que subiste
        texIdle = Texture("Pink Man/Idle (32x32).png")
        texRun = Texture("Pink Man/Run (32x32).png")
        texDoubleJump = Texture("Pink Man/Double Jump (32x32).png")
        texJump = Texture("Pink Man/Jump (32x32).png")
        texFall = Texture("Pink Man/Fall (32x32).png")

        // Instanciamos al jugador pasándole estas texturas
        jugador = Jugador(texIdle, texRun, texJump, texDoubleJump, texFall)

        camera.setToOrtho(false, 800f, 480f)
    }

    override fun render(delta: Float) {


        tiempoTranscurrido += delta
        val velocidadMundo = 100f // El mapa se mueve a 100px/s
        val velocidadCaminar = 400f * delta
        var moviendose = false
        var haciendoDobleSalto = false


        // 1. INPUT INDEPENDIENTE (Sin else-if para permitir acciones combinadas)
        if (Gdx.input.isKeyPressed(Input.Keys.D)) {
            jugador.posicionX += velocidadCaminar
            jugador.mirandoDerecha = true
            moviendose = true
        }
        if (Gdx.input.isKeyPressed(Input.Keys.A)) {
            jugador.posicionX -= velocidadCaminar
            jugador.mirandoDerecha = false
            moviendose = true
        }

        // Salto con SPACE (solo si está en el suelo)
        if (Gdx.input.isKeyPressed(Input.Keys.SPACE) && !jugador.estaEnAire) {
            jugador.velocidadY = 600f // Impulso hacia arriba
        }

        // Simulación de Doble Salto con F
        if (Gdx.input.isKeyPressed(Input.Keys.F)) {
            haciendoDobleSalto = true
        }



        // 2. ACTUALIZACIÓN: Aplicamos el arrastre del mapa
        jugador.update(delta, velocidadMundo-50f)

        // 3. CÁMARA SIGUE AL JUGADOR
//        camera.position.set(jugador.posicionX, 240f, 0f) // Mantener altura fija o seguir Y
//        camera.update()

        camera.position.x = jugador.posicionX
        camera.update()

        // 4. DIBUJADO
        ScreenUtils.clear(0f, 0f, 0f, 1f)
        batch.projectionMatrix = camera.combined
        batch.use { b ->
            val anchoMapa = texturaMapa.width.toFloat()
            // Dibujamos varias capas de fondo para que no se acabe
//            b.draw(texturaMapa, -anchoMapa, 0f)
//            b.draw(texturaMapa, 0f, 0f)
//            b.draw(texturaMapa, anchoMapa, 0f)

            val offsetMapa = (jugador.posicionX / anchoMapa).toInt()

            for (i in -1..2) {
                b.draw(texturaMapa, (offsetMapa + i) * anchoMapa, 0f)
            }

            // Pintamos al jugador
            val frameActual = jugador.getFrame( moviendose, false)
            b.draw(
                frameActual,
                jugador.posicionX - 16f, // Centrado
                jugador.posicionY,
                32f, 32f
            )

            val matrizUI = camera.combined.cpy().setToOrtho2D(0f, 0f, 800f, 480f)
            b.projectionMatrix = matrizUI

            font.data.setScale(2f) // Hacer la letra un poco más grande
            val minutos = (tiempoTranscurrido / 60).toInt()
            val segundos = (tiempoTranscurrido % 60).toInt()
            val tiempoTexto = String.format("%02d:%02d", minutos, segundos)

            font.draw(b, "TIEMPO: $tiempoTexto", 20f, 460f)
        }
    }

    override fun dispose() {
        batch.disposeSafely()
        font.dispose() // ¡Importante!
    }
}
