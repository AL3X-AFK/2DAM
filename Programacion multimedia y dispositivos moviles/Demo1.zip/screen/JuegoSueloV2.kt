package asir2.juego1.screen


import asir2.juego1.screen.GameScreen
import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.Texture.TextureFilter.Linear
import com.badlogic.gdx.graphics.g2d.Batch
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.graphics.g2d.TextureRegion
import com.badlogic.gdx.utils.ScreenUtils
import com.badlogic.gdx.utils.viewport.FitViewport
import ktx.app.KtxGame
import ktx.app.KtxScreen
import ktx.app.clearScreen
import ktx.assets.disposeSafely
import ktx.assets.toInternalFile
import ktx.async.KtxAsync
import ktx.graphics.use

class JuegoSueloV2 : KtxScreen {
    private val batch = SpriteBatch()
    private val texturaCompleta = Texture("Terrain (16x16).png")
    private lateinit var tileHierba: TextureRegion

    // 1. Añadimos una cámara y un visor para que el juego sea responsive
    private val camera = OrthographicCamera()
    private val viewport = FitViewport(320f, 180f, camera) // Resolución virtual fija

    override fun show() {
        texturaCompleta.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest)
        // Extraemos el tile (ajustado a 16x16 según tu variable)
        tileHierba = TextureRegion(texturaCompleta, 128, 0, 16, 16)
    }

    override fun render(delta: Float) {
        ScreenUtils.clear(0.1f, 0.1f, 0.1f, 1f)

        // 2. Actualizamos la cámara
        camera.update()
        batch.projectionMatrix = camera.combined

        batch.use { b ->
            // Ahora dibujas en coordenadas del "mundo", no de la pantalla
            for (x in 0 until 20) { // Dibujamos 20 columnas fijas
                for (y in 0 until 3) {
                    b.draw(tileHierba, x * 16f, y * 16f, 16f, 16f)
                }
            }
        }
    }

    override fun resize(width: Int, height: Int) {
        viewport.update(width, height, true)
    }

    override fun dispose() {
        batch.dispose()
        texturaCompleta.dispose()
    }
}
