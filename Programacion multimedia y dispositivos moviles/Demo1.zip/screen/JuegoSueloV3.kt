package asir2.juego1.screen


import asir2.juego1.screen.GameScreen
import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.Texture.TextureFilter.Linear
import com.badlogic.gdx.graphics.g2d.Batch
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.graphics.g2d.TextureRegion
import com.badlogic.gdx.utils.ScreenUtils
import com.badlogic.gdx.utils.viewport.FitViewport
import ktx.app.KtxGame
import ktx.app.KtxScreen
import ktx.app.clearScreen
import ktx.assets.disposeSafely
import ktx.assets.toInternalFile
import ktx.async.KtxAsync
import ktx.graphics.use

class JuegoSueloV3 : KtxScreen {
    private val batch = SpriteBatch()
    private val camera = OrthographicCamera()
    private val texturaMapa = Texture("map.png") // Usamos tu imagen de mapa completa

    // Posición virtual de nuestra cámara
    private var camX = 400f

    override fun show() {
        // Configuramos la cámara para ver un área de 800x480 unidades
        camera.setToOrtho(false, 800f, 480f)
    }

    override fun render(delta: Float) {
        ScreenUtils.clear(0f, 0f, 0f, 1f)

        // 1. Lógica: Movemos la posición teórica (puedes vincular esto a las flechas del teclado)
        val velocidad = 200f // píxeles por segundo
        camX += velocidad * delta

        // 2. Actualizamos la cámara
        camera.position.set(camX, camera.position.y, 0f)
        camera.update() // ¡Vital! Calcula la nueva matriz de vista

        // 3. Dibujamos
        batch.projectionMatrix = camera.combined // Le decimos al batch que use la cámara
        batch.use { b ->
            val anchoMapa = texturaMapa.width.toFloat()

            // Dibujamos el mapa original
            b.draw(texturaMapa, 0f, 0f)

            // Dibujamos una copia justo donde termina el primero
            b.draw(texturaMapa, anchoMapa, 0f)

            // Si camX supera el ancho del mapa, la reseteamos (Teletransporte invisible)
            if (camX > anchoMapa + 400f) {
                camX = 400f
            }
        }
    }

}
