package asir2.juego1.entity

import com.badlogic.gdx.math.Rectangle

class Obstaculo(x: Float, y: Float) {
    val hitbox = Rectangle(x, y, 32f, 32f)
}
