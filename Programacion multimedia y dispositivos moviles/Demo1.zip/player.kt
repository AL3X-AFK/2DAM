package asir2.juego1

import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.g2d.Animation
import com.badlogic.gdx.graphics.g2d.TextureRegion
import com.badlogic.gdx.math.Rectangle

class Jugador(texturaRun: Texture, texturaIdle: Texture, texturaJump: Texture, texturaDoubleJump: Texture, texturaFall: Texture) {

    private val animIdle: Animation<TextureRegion>
    private val animRun: Animation<TextureRegion>
    private val animDoubleJump: Animation<TextureRegion>
    private val regJump: TextureRegion
    private val regFall: TextureRegion
    // Animaciones
    private lateinit var animacionCorrer: Animation<TextureRegion>
    private lateinit var animacionQuieto: Animation<TextureRegion>

    var posicionX = 400f
    var posicionY = 36f // Ajustado para que pise el suelo gris
    var velocidadY = 0f
    var estaEnAire = false
    var mirandoDerecha = true
    var stateTime = 0f
    var velocidadMundo = 100f

    init {
        // Configuramos la animación de CORRER (Run 32x32 tiene 12 frames)
        val regionesRun = TextureRegion.split(texturaRun, 32, 32)[0]
        animacionCorrer = Animation(0.05f, com.badlogic.gdx.utils.Array(regionesRun), Animation.PlayMode.LOOP)

        // Configuramos la animación de QUIETO (Idle 32x32 tiene 11 frames)
        val regionesIdle = TextureRegion.split(texturaIdle, 32, 32)[0]
        animacionQuieto = Animation(0.05f, com.badlogic.gdx.utils.Array(regionesIdle), Animation.PlayMode.LOOP)

        // 1. Configurar Idle (11 frames según la imagen)
        val framesIdle = TextureRegion.split(texturaIdle, 32, 32)[0]
        animIdle = Animation(0.1f, *framesIdle) // El '*' expande el array en Kotlin
        animIdle.playMode = Animation.PlayMode.LOOP

        // 2. Configurar Run (12 frames según la imagen)
        val framesRun = TextureRegion.split(texturaRun, 32, 32)[0]
        animRun = Animation(0.05f, *framesRun)
        animRun.playMode = Animation.PlayMode.LOOP

        val framesJump = TextureRegion.split(texturaDoubleJump, 32, 32)[0]
        animDoubleJump = Animation(0.05f, *framesJump)
        animDoubleJump.playMode = Animation.PlayMode.LOOP

        // 3. Jump y Fall (Suelen ser un solo frame o pocos)
        regJump = TextureRegion.split(texturaJump, 32, 32)[0][0]
        regFall = TextureRegion.split(texturaFall, 32, 32)[0][0]
    }

    fun update(delta: Float, velocidadAvance: Float) {
        stateTime += delta

        // Avance automático: el mundo se mueve y el jugador avanza con él
        posicionX += velocidadAvance * delta

        // Gravedad y Salto
        if (posicionY > 36f || velocidadY != 0f) {
            velocidadY -= 1500f * delta // Fuerza de gravedad
            estaEnAire = true
        }

        posicionY += velocidadY * delta

        // Suelo (colisión con la línea gris)
        if (posicionY <= 36f) {
            posicionY = 36f
            velocidadY = 0f
            estaEnAire = false
        }
    }

    fun getFrame(estaMoviendose: Boolean, dobleSalto: Boolean): TextureRegion {
        val frame = when {
            dobleSalto -> animDoubleJump.getKeyFrame(stateTime)
            estaEnAire && velocidadY > 0 -> regJump
            estaEnAire && velocidadY <= 0 -> regFall
            estaMoviendose -> animRun.getKeyFrame(stateTime)
            else -> animIdle.getKeyFrame(stateTime)
        }

        if ((mirandoDerecha && frame.isFlipX) || (!mirandoDerecha && !frame.isFlipX)) {
            frame.flip(true, false)
        }
        return frame
    }

    fun getHitbox(): Rectangle {
        // Creamos un rectángulo un poco más pequeño que el dibujo (20x28)
        // para que la colisión sea más precisa y justa.
        return Rectangle(posicionX + 6f, posicionY, 20f, 28f)
    }
}


